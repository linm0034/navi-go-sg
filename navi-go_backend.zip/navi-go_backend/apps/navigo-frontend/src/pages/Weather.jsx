import React, { useState, useEffect } from 'react';
import { weatherAPI } from '../services/api';
import Loading from '../components/Loading';

const Weather = () => {
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchWeather();
  }, []);

  const fetchWeather = async () => {
    try {
      setLoading(true);
      const response = await weatherAPI.getCurrentWeather();
      setWeather(response.data);
      setError(null);
    } catch (err) {
      setError('Failed to load weather data. Please try again later.');
      console.error('Error fetching weather:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <Loading message="Loading weather data..." />;

  if (error) {
    return (
      <div className="card">
        <div className="error">{error}</div>
        <button onClick={fetchWeather} className="btn btn-primary">
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="weather-page">
      <div className="card">
        <h1>🌤️ Weather Forecast</h1>
        <p style={{ color: '#666', marginBottom: '2rem' }}>
          Current weather conditions in Singapore
        </p>
      </div>

      {weather && (
        <div className="card" style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>
            {weather.icon || '☀️'}
          </div>
          <h2 style={{ fontSize: '3rem', marginBottom: '1rem' }}>
            {weather.temperature || '30'}°C
          </h2>
          <p style={{ fontSize: '1.5rem', color: '#666', marginBottom: '2rem' }}>
            {weather.condition || 'Partly Cloudy'}
          </p>
          
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
            gap: '1rem',
            marginTop: '2rem'
          }}>
            <div>
              <p style={{ color: '#666' }}>Humidity</p>
              <p style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>
                {weather.humidity || '75'}%
              </p>
            </div>
            <div>
              <p style={{ color: '#666' }}>Wind Speed</p>
              <p style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>
                {weather.windSpeed || '15'} km/h
              </p>
            </div>
            <div>
              <p style={{ color: '#666' }}>Precipitation</p>
              <p style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>
                {weather.precipitation || '20'}%
              </p>
            </div>
            <div>
              <p style={{ color: '#666' }}>UV Index</p>
              <p style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>
                {weather.uvIndex || '8'}
              </p>
            </div>
          </div>

          <button 
            onClick={fetchWeather} 
            className="btn btn-secondary" 
            style={{ marginTop: '2rem' }}
          >
            🔄 Refresh
          </button>
        </div>
      )}

      <div className="card">
        <h3>Weather Tips</h3>
        <ul style={{ lineHeight: '2', color: '#666', paddingLeft: '1.5rem' }}>
          <li>Singapore has a tropical climate with high humidity year-round</li>
          <li>Best time to visit is from February to April</li>
          <li>Always carry an umbrella for sudden rain showers</li>
          <li>Stay hydrated and use sunscreen when outdoors</li>
        </ul>
      </div>
    </div>
  );
};

export default Weather;
