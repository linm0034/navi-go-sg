import React, { useState, useEffect } from 'react';
import { hotelAPI } from '../services/api';
import Loading from '../components/Loading';

const Hotels = () => {
  const [hotels, setHotels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchHotels();
  }, []);

  const fetchHotels = async () => {
    try {
      setLoading(true);
      const response = await hotelAPI.getHotels();
      setHotels(response.data);
      setError(null);
    } catch (err) {
      setError('Failed to load hotels. Please try again later.');
      console.error('Error fetching hotels:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <Loading message="Loading hotels..." />;

  if (error) {
    return (
      <div className="card">
        <div className="error">{error}</div>
        <button onClick={fetchHotels} className="btn btn-primary">
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="hotels-page">
      <div className="card">
        <h1>🏨 Hotel Rankings</h1>
        <p style={{ color: '#666', marginBottom: '2rem' }}>
          Discover the best hotels in Singapore based on ratings, amenities, and location.
        </p>
      </div>

      {hotels.length === 0 ? (
        <div className="card">
          <p>No hotels available at the moment.</p>
        </div>
      ) : (
        <div className="feature-grid">
          {hotels.map((hotel, index) => (
            <div key={index} className="card">
              <h3 style={{ color: 'var(--primary-color)', marginBottom: '0.5rem' }}>
                {hotel.name || `Hotel ${index + 1}`}
              </h3>
              {hotel.rating && (
                <p style={{ fontSize: '1.2rem', marginBottom: '0.5rem' }}>
                  ⭐ {hotel.rating}/5
                </p>
              )}
              {hotel.address && (
                <p style={{ color: '#666', marginBottom: '0.5rem' }}>
                  📍 {hotel.address}
                </p>
              )}
              {hotel.price && (
                <p style={{ fontWeight: 'bold', color: 'var(--secondary-color)' }}>
                  ${hotel.price} / night
                </p>
              )}
              {hotel.amenities && (
                <div style={{ marginTop: '1rem' }}>
                  <p style={{ fontWeight: '600', marginBottom: '0.5rem' }}>Amenities:</p>
                  <p style={{ color: '#666', fontSize: '0.9rem' }}>
                    {hotel.amenities.join(', ')}
                  </p>
                </div>
              )}
              <button className="btn btn-primary" style={{ marginTop: '1rem', width: '100%' }}>
                View Details
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Hotels;
