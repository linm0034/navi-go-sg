import express from 'express';

const app = express();
app.use(express.json());

// Simple in-memory list of bookings
let bookings = [];

// Create a new booking. For demo purposes the request body
// is simply stored in memory.
app.post('/', (req, res) => {
  bookings.push(req.body);
  res.json({ success: true });
});

// Return all bookings for the current user. For now this just
// returns the full list for demonstration purposes.
app.get('/me', (_req, res) => {
  res.json(bookings);
});

const port = process.env.BOOKING_PORT || 4015;
app.listen(port, () => {
  console.log(`Booking API listening on ${port}`);
});