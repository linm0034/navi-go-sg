prerequisites

you need npm

how to use

cd to folder and type npm install

run with npm start
