// Placeholder utility module. Add shared functions here.
export function noop() {}